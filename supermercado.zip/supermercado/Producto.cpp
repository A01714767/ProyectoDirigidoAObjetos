#include "Producto.h"

Producto::Producto() : id(0), nombre(""), precio(0.0) {}

Producto::Producto(int id, std::string nombre, double precio)
    : id(id), nombre(nombre), precio(precio) {}

int Producto::getId() const { return id; }
std::string Producto::getNombre() const { return nombre; }
double Producto::getPrecio() const { return precio; }

void Producto::setPrecio(double nuevo) { precio = nuevo; }
