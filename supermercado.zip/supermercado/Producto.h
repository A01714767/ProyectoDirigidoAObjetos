#ifndef PRODUCTO_H
#define PRODUCTO_H

#include <string>

class Producto {
private:
    int id;
    std::string nombre;
    double precio;

public:
    Producto();
    Producto(int id, std::string nombre, double precio);

    int getId() const;
    std::string getNombre() const;
    double getPrecio() const;

    void setPrecio(double nuevo);
};

#endif
