#include "Carrito.h"
#include <iostream>
#include <iomanip>

void Carrito::agregarProducto(const Producto& p) {
    productos.push_back(p);
}

double Carrito::total() const {
    double suma = 0;
    for (const auto& p : productos) {
        suma += p.getPrecio();
    }
    return suma;
}

void Carrito::mostrar() const {
    std::cout << "\n--- Carrito de Compras ---\n";
    for (const auto& p : productos) {
        std::cout << p.getNombre() << " - $" 
                  << std::fixed << std::setprecision(2) 
                  << p.getPrecio() << "\n";
    }
    std::cout << "TOTAL = $" << total() << "\n";
}
