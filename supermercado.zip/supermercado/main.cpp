#include <iostream>
#include "Supermercado.h"
#include "Cliente.h"

int main() {
    Supermercado mercado;

    // Crear y agregar productos
    mercado.agregarProducto(Producto(1, "pan", 1.00));
    mercado.agregarProducto(Producto(2, "leche", 1.50));
    mercado.agregarProducto(Producto(3, "arroz", 2.00));
    mercado.agregarProducto(Producto(4, "huevos", 2.50));
    mercado.agregarProducto(Producto(5, "manzana", 0.75));

    mercado.mostrarInventario();

    Cliente c("Leonardo");

    std::string nombre;
    while (true) {
        std::cout << "\nIngresa un producto (fin para terminar): ";
        std::cin >> nombre;

        if (nombre == "fin") break;

        Producto p = mercado.buscarProducto(nombre);

        if (p.getNombre() != "NULL")
            c.agregarAlCarrito(p);
        else
            std::cout << "Producto no encontrado.\n";
    }

    c.mostrarCarrito();

    return 0;
}
