#include "Supermercado.h"
#include <iostream>
#include <iomanip>

void Supermercado::agregarProducto(const Producto& p) {
    inventario.push_back(p);
}

Producto Supermercado::buscarProducto(const std::string& nombre) const {
    for (const auto& p : inventario) {
        if (p.getNombre() == nombre) {
            return p;
        }
    }
    return Producto(0, "NULL", 0.0);
}

void Supermercado::mostrarInventario() const {
    std::cout << "\n--- Inventario del Supermercado ---\n";
    for (const auto& p : inventario) {
        std::cout << p.getId() << " - " << p.getNombre()
                  << " - $" << std::fixed << std::setprecision(2)
                  << p.getPrecio() << "\n";
    }
}
