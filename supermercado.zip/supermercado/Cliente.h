#ifndef CLIENTE_H
#define CLIENTE_H

#include <string>
#include "Carrito.h"

class Cliente {
private:
    std::string nombre;
    Carrito carrito;

public:
    Cliente(std::string nombre);
    void agregarAlCarrito(const Producto& p);
    void mostrarCarrito() const;
};

#endif
