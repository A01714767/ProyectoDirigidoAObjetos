#ifndef SUPERMERCADO_H
#define SUPERMERCADO_H

#include <vector>
#include "Producto.h"

class Supermercado {
private:
    std::vector<Producto> inventario;

public:
    void agregarProducto(const Producto& p);
    Producto buscarProducto(const std::string& nombre) const;
    void mostrarInventario() const;
};

#endif
