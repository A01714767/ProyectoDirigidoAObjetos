#include "Cliente.h"
#include <iostream>

Cliente::Cliente(std::string nombre) : nombre(nombre) {}

void Cliente::agregarAlCarrito(const Producto& p) {
    carrito.agregarProducto(p);
}

void Cliente::mostrarCarrito() const {
    std::cout << "\nCliente: " << nombre << "\n";
    carrito.mostrar();
}
